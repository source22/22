import json
import urllib2
from datetime import datetime
from dateutil import tz
import pytz
import time


class Events(object):
    def __init__(self, working_timezone, ignore_expired=False):
        self.schedule_timezone = "America/New_York"
        self.working_timezone = working_timezone
        self.ignore_expired = ignore_expired
        self.channel_info = {}
        self.category_list = []
        self.event_list = []

        data = json.loads(urllib2.urlopen('http://guide.smoothstreams.tv/feed.json').read())

        for channel in data:
            self.channel_info[channel] = {"name": data[channel]['name'], "image": data[channel]['img']}
            if 'items' in data[channel]:
                event_items = data[channel]['items']
                for event in event_items:
                    if self.ignore_expired:
                        if self.has_ended(self.convert_timezone(event['end_time'], self.schedule_timezone, self.working_timezone)):
                            continue
                    if event['category'] == '':
                        event['category'] = 'Uncategorised'
                    if event['category'] not in self.category_list:
                        self.category_list.append(event['category'])
                    event['time'] = self.convert_timezone(event['time'], self.schedule_timezone, self.working_timezone)
                    event['end_time'] = self.convert_timezone(event['end_time'], self.schedule_timezone, self.working_timezone)
                    self.event_list.append(event)

        self.category_list = sorted(self.category_list)

    def get_datetime_formatter(self, _timezone):
        formatter = "%Y-%m-%d %H:%M:%S"
        if _timezone == "Europe/London":
            formatter = "%d-%m-%Y %H:%M:%S"
        if _timezone == "America/Los_Angeles":
            formatter = "%Y-%m-%d %H:%M:%S"
        if _timezone == "America/Chicago":
            formatter = "%Y-%m-%d %H:%M:%S"
        if _timezone == "America/New_York":
            formatter = "%Y-%m-%d %H:%M:%S"
        if _timezone == "UTC":
            formatter = "%Y-%m-%d %H:%M:%S"
        if _timezone == "Europe/Amsterdam":
            formatter = "%Y-%m-%d %H:%M:%S"
        if _timezone == "Asia/Hong_Kong":
            formatter = "%Y-%m-%d %H:%M:%S"
        return formatter

    def today(self, str=True):
        current_datetime = datetime.now(tz=pytz.timezone(self.working_timezone))
        if not str:
            return current_datetime
        else:
            return datetime.strftime(current_datetime, self.get_datetime_formatter(self.working_timezone))

    def new_strptime(self, datetime_string, _tz):
        try:
            datetime_string = datetime.strptime(datetime_string, self.get_datetime_formatter(_tz))
        except TypeError:
            datetime_string = datetime(*(time.strptime(datetime_string, self.get_datetime_formatter(_tz))[0:6]))
        return datetime_string

    def new_strptime_fmt(self, datetime_string, _format):
        try:
            datetime_string = datetime.strptime(datetime_string, _format)
        except TypeError:
            datetime_string = datetime(*(time.strptime(datetime_string, _format)[0:6]))
        return datetime_string

    def convert_timezone(self, datetime_string, nieve_input_tz, nieve_output_tz):
        try:
            input_tz = pytz.timezone(str(nieve_input_tz))
        except:
            input_tz = tz.gettz(self.schedule_timezone)
        try:
            output_tz = pytz.timezone(str(nieve_output_tz))
        except:
            output_tz = tz.gettz(self.working_timezone)


        datetime_string = self.new_strptime(datetime_string, nieve_input_tz)
        datetime_string = input_tz.localize(datetime_string)
        datetime_string = datetime_string.astimezone(output_tz)
        datetime_string = datetime_string.strftime(self.get_datetime_formatter(nieve_output_tz))

        return datetime_string

    def has_ended(self, input_date):
        end_datetime = self.new_strptime(input_date, self.working_timezone)
        end_datetime = end_datetime.replace(tzinfo=pytz.timezone(self.working_timezone))
        current_datetime = self.today(True)
        current_datetime = self.new_strptime(current_datetime, self.working_timezone)
        current_datetime = current_datetime.replace(tzinfo=pytz.timezone(self.working_timezone))

        if end_datetime < current_datetime:
            return True
        else:
            return False

    def has_started(self, input_date):
        start_datetime = self.new_strptime(input_date, self.working_timezone)
        start_datetime = start_datetime.replace(tzinfo=pytz.timezone(self.working_timezone))
        current_datetime = self.today(True)
        current_datetime = self.new_strptime(current_datetime, self.working_timezone)
        current_datetime = current_datetime.replace(tzinfo=pytz.timezone(self.working_timezone))

        if current_datetime > start_datetime:
            return True
        else:
            return False

    def get_event_dates(self):
        date_list = []
        for event in self.event_list:
            if event['time'] not in date_list:
                if self.ignore_expired:
                    if not self.has_ended(event['end_time']):
                        date_list.append(event['time'])
                else:
                    date_list.append(event['time'])
        ret_date_list = []
        for date in date_list:
            if date[0:10] not in ret_date_list:
                ret_date_list.append(date[0:10])
        return sorted(ret_date_list, key=lambda x: self.new_strptime_fmt(x, self.get_datetime_formatter(self.working_timezone)[0:8]))

    def get_unique_events_list(self, category=None, date=None, filter_future=False):
        to_make_set = []

        if category is None and date is None:
            for event in self.event_list:
                to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        if category is not None and date is None:
            for event in self.event_list:
                if event['category'] == category:
                    if filter_future is True:
                        if event['time'][0:10] != self.today(True)[0:10]:
                            continue
                    to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        if category is None and date is not None:
            for event in self.event_list:
                if event['time'][0:10] == date[0:10]:
                    to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        if category is not None and date is not None:
            for event in self.event_list:
                if event['category'] == category and event['time'][0:10] == date[0:10]:
                    to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        output_list = list(set(to_make_set))
        return sorted(output_list)

    def get_event_by_name(self, name, date=None):
        to_make_set = []
        if date is None:
            for event in self.event_list:
                if event['name'] == name:
                    to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        if date is not None:
            for event in self.event_list:
                if event['name'] == name and event['time'][0:10] == date[0:10]:
                    to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        return list(set(to_make_set))

    def get_event_options(self, name, datetime_string=None):
        if datetime_string is None:
            datetime_string = self.today(True)
        option_list = []
        for event in self.event_list:
                if event['name'] == name and event['time'] == datetime_string:
                    option_list.append(event)

        return sorted(option_list)

    def get_now_playing(self):
        to_make_set = []
        for event in self.event_list:
            if self.today(True)[0:10] == event['time'][0:10]:
                if self.has_started(self.convert_timezone(event['time'], self.working_timezone, self.working_timezone)):
                    if not self.has_ended(event['end_time']):
                        #Must be playing now
                        to_make_set.append(event['time']+'~@~'+event['name']+'~@~'+event['end_time'])
        return sorted(list(set(to_make_set)))

    def get_channel_image(self, channel):
        return self.channel_info[channel]['image']

    def get_channel_name(self, channel):
        return self.channel_info[channel]['name']


