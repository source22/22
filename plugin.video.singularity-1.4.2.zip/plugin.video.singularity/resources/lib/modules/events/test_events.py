from unittest import TestCase
import event_data
events = event_data.Events("Europe/London", True)

class TestEvents(TestCase):
    def test_convert_timezone(self):
        result = events.convert_timezone("2017-06-04 23:00:00", "America/New_York", "Europe/London")
        self.assertEqual("05-06-2017 04:00:00", result, "Result Not as Expected")

    def test_has_ended(self):
        pass