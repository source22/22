import event_data


def controller(view, params, _timezone, show_expired, panel_module=None, auto_resolve=True, filter_future=True):

    events = event_data.Events(working_timezone=_timezone, ignore_expired=show_expired)

    def get_events(date=None, cat=None):
        return events.get_unique_events_list(category=cat, date=date, filter_future=filter_future)

    def get_dates():
        return events.get_event_dates()

    def get_categories():
        return events.category_list

    def get_options(event_name, datetime_string=None):
        return events.get_event_options(event_name, datetime_string)

    def get_now_playing():
        return events.get_now_playing()

    def get_channel_name(channel):
        return events.get_channel_name(channel=channel)

    def get_today(Str=True):
        return events.today(Str)

    '''
    The purpose of this method is to control all usage of the schedule,
    This allows addon users to add one route to there addon for the schedule
    and the schedule do the rest.
    '''
    mode = params['sc_mode']
    if 'sc_mode' in params:
        if mode == 'show_dates':
            view.show_dates(get_dates())
        if mode == 'show_categorys':
            view.show_categories(get_categories())
        if mode == 'show_all_events':
            view.show_all_events(get_events(), get_today(True))
        if mode == 'show_all_todays_events':
            view.show_all_events(get_events(date=events.today(True)), get_today(True))
        if mode == 'show_by_category':
            view.show_all_events(get_events(cat=params['sc_cat']), get_today(True))
        if mode == 'show_by_date':
            view.show_all_events(get_events(date=params['sc_date']), get_today(True))

        if mode == 'show_dates_and_categorys_pick_date':
            view.show_dc_pick_dates(get_dates())
        if mode == 'show_dates_and_categorys_pick_category':
            view.show_dc_pick_category(get_categories(), sc_dc_date=params['sc_dc_date'])
        if mode == 'show_date_and_category_pick':
            view.show_all_events(get_events(date=params['sc_dc_date'], cat=params['sc_dc_cat']), get_today(True))

        if mode == 'show_categorys_and_dates_pick_category':
            view.show_cd_pick_category(get_categories())
        if mode == 'show_categorys_and_dates_pick_date':
            view.show_cd_pick_dates(get_dates(), sc_cd_cat=params['sc_cd_cat'])
        if mode == 'show_category_and_date_pick':
            view.show_all_events(get_events(cat=params['sc_cd_cat'], date=params['sc_cd_date']), get_today(True))

        if mode == 'show_event_options':
            view.show_event_options(get_options(event_name=params['sc_event'], datetime_string=params['sc_date']), events)

        if mode == 'show_now_playing':
            view.show_all_events(get_now_playing(), get_today(True))

        if mode == 'resolve_channel':
            if panel_module is None:
                view.display_error('No Panel Module', 'No panel module set, so unable to play channel.')
            else:
                if auto_resolve is True:
                    panel_module.resolve_channel_by_number_and_string_auto('Channel', params['sc_channel'], event_name=params['sc_event'])
                else:
                    panel_module.resolve_channel_by_number(params['sc_channel'], event_name=params['sc_event'])


