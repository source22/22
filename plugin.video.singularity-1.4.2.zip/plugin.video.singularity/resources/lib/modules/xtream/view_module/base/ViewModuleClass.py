from abc import ABCMeta, abstractmethod


class ViewModuleClass:
    __metaclass__ = ABCMeta

    # Base Display Objects

    @abstractmethod
    def modal(self, header, message1, message2=None, message3=None):
        pass

    @abstractmethod
    def modal_panel(self, heading, message):
        pass

    @abstractmethod
    def show_main_menu(self, live_menu_name=None, vod_menu_name=None, live_stream_categorys=None, vod_stream_categorys=None):
        pass

    # SHOW CATEGORY'S

    @abstractmethod
    def show_live_stream_categories(self, data):
        pass

    @abstractmethod
    def show_vod_categories(self, data):
        pass

    # SHOW CATEGORY

    @abstractmethod
    def show_live_stream_category(self, data):
        pass

    @abstractmethod
    def show_vod_category(self, data):
        pass

    # ALL STREAMS

    @abstractmethod
    def show_all_live_streams(self, data):
        pass

    @abstractmethod
    def show_all_vod_streams(self, data):
        pass

    # ACCOUNT INFORMATION

    @abstractmethod
    def show_account_information(self, data, args):
        pass

    # PLAY CODE

    @abstractmethod
    def play(self, server_data, **kwargs):
        pass

    # RESOLVER RESULTS

    @abstractmethod
    def show_resolver_results(self):
        pass