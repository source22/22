# -*- coding: utf-8 -*-

# ###KODI VIEW MODULE###

# Version Master #
# version:0.0.3 #

import base.ViewModuleClass as ViewMClass

VMC = ViewMClass.ViewModuleClass
import sys
import urllib
import urlparse
import datetime
import base64

import xbmc
import xbmcgui
import xbmcplugin

__handle__ = int(sys.argv[1])


class ViewModule(VMC):
    def __init__(self, stream_preference=None, default_fanart=None, default_icon=None, mpegts=False):
        self.stream_preference = stream_preference if stream_preference is not None else "m3u8"
        self.params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))
        self.default_icon = default_icon
        self.default_fanart = default_fanart
        self.mpegts = mpegts

    def __build_url(self, query):
        return sys.argv[0] + "?" + "mode=xtream&default_icon=%s&default_fanart=%s&" % (
        self.default_icon, self.default_fanart) + urllib.urlencode(query)

    def modal(self, header, message1, message2=None, message3=None):
        xbmcgui.Dialog().ok(header, message1, message2, message3)

    def modal_panel(self, heading, message):
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(100)
        win = xbmcgui.Window(id)
        retry = 50
        while retry > 0:
            try:
                xbmc.sleep(10)
                retry -= 1
                win.getControl(1).setLabel(heading)
                win.getControl(5).setText(message)
                return
            except:
                pass

    # To keep things cleaner a little add method helps, as if some part
    # of the kodi code changes breaking display of menu items, we can just
    # fix in the one place.
    def __add_menu_item(self, label, url, icon, fanart, isfolder=True):
        li = xbmcgui.ListItem(label=label, iconImage=icon, thumbnailImage=icon)
        li.setProperty("fanart_image", fanart)
        xbmcplugin.addDirectoryItem(__handle__, url, li, isfolder)

    def __add_media_item(self, label):
        pass

    # def make_kodi_play_url(self, xtream_mode, stream_id, stream_display_name, stream_type, direct_source):
    def make_kodi_play_url(self, stream_object, sender):
        icon = stream_object['stream_icon'] if stream_object['stream_icon'] != '' else self.default_icon
        kodi_play_url = self.__build_url(
            {
                "xtream_mode": 'play',
                "xtream_id": stream_object['stream_id'],
                "xtream_name": stream_object['name'],
                "xtream_type": sender,
                "direct_source": stream_object['direct_source'],
                'default_icon': icon,
                "default_fanart": self.default_fanart
            })
        return kodi_play_url

    def show_main_menu(self, live_menu_name=None, vod_menu_name=None, live_stream_categorys=None,
                       vod_stream_categorys=None):
        if live_stream_categorys and not vod_stream_categorys:
            self.show_live_stream_categories(live_stream_categorys)
        elif vod_stream_categorys and not live_stream_categorys:
            self.show_vod_categories(vod_stream_categorys)
        elif live_stream_categorys and vod_stream_categorys:
            li = xbmcgui.ListItem(label=live_menu_name, iconImage=self.default_icon, thumbnailImage=self.default_icon)
            url = self.__build_url({"xtream_mode": "live_stream_main_menu"})
            li.setProperty("fanart_image", self.default_fanart)
            xbmcplugin.addDirectoryItem(__handle__, url, li, False)
            # Show VOD Menu Option
            li = xbmcgui.ListItem(label=vod_menu_name, iconImage=self.default_icon, thumbnailImage=self.default_icon)
            url = self.__build_url({"xtream_mode": "vod_main_menu"})
            li.setProperty("fanart_image", self.default_fanart)
            xbmcplugin.addDirectoryItem(__handle__, url, li, False)
            xbmcplugin.endOfDirectory(__handle__)
        else:
            return None

    # SHOW CATEGORY'S

    def show_live_stream_categories(self, data):
        url = self.__build_url({"xtream_mode": "show_all_live_streams"})
        self.__add_menu_item(label="All Streams", url=url, icon=self.default_icon, fanart=self.default_fanart, isfolder=True)
        for category in data:
            url = self.__build_url(
                {"xtream_mode": "show_streams_by_category", "xtream_category": category["category_id"]})
            self.__add_menu_item(label=category["category_name"], url=url, icon=self.default_icon, fanart=self.default_fanart,
                                 isfolder=True)
        xbmcplugin.endOfDirectory(__handle__)

    def show_vod_categories(self, data, parent_category_id=0, streams=None):
        print streams
        if int(parent_category_id) == 0:
            url = self.__build_url({"xtream_mode": "show_all_vod_streams"})
            self.__add_menu_item(label="All Streams", url=url, icon=self.default_icon, fanart=self.default_fanart, isfolder=True)

        for category in data:
            if int(category['parent_id']) == int(parent_category_id):
                category_has_children = False
                for inner_category in data:
                    if int(inner_category['parent_id']) == int(category['category_id']):
                        category_has_children = True

                if category_has_children is True:
                    url = self.__build_url({"xtream_mode": "vod_main_menu", "parent_category_id": category["category_id"]})
                    self.__add_menu_item(label=category["category_name"], url=url, icon=self.default_icon, fanart=self.default_fanart,
                                         isfolder=True)
                else:
                    url = self.__build_url({"xtream_mode": "show_vod_by_category", "xtream_category": category["category_id"]})
                    self.__add_menu_item(label=category["category_name"], url=url, icon=self.default_icon, fanart=self.default_fanart,
                                         isfolder=True)

            else:
                pass
        for stream in streams:
            if stream['category_id'] == parent_category_id:
                url = self.make_kodi_play_url(stream, 'movie')
                self.__add_menu_item(label=stream["name"], url=url, icon=self.default_icon,
                                         fanart=self.default_fanart, isfolder=False)

        xbmcplugin.endOfDirectory(__handle__)

    # SHOW CATEGORY

    def show_live_stream_category(self, data):
        for live_stream in data:
            name = live_stream['name']
            icon = live_stream['stream_icon'] if live_stream['stream_icon'] != '' else self.default_icon
            url = self.make_kodi_play_url(live_stream, 'live')
            # url = self.make_kodi_play_url("play", live_stream["stream_id"], live_stream["name"], "live", live_stream["direct_source"])
            self.__add_menu_item(label=name, url=url, icon=icon, fanart=self.default_fanart, isfolder=False)
        xbmcplugin.endOfDirectory(__handle__)

    def show_vod_category(self, data):
        for vod_stream in data:
            icon = vod_stream['stream_icon'] if vod_stream['stream_icon'] != '' else self.default_icon
            url = self.make_kodi_play_url(vod_stream, 'movie')
            # url = self.make_kodi_play_url("play", vod_stream["stream_id"], vod_stream["name"], "vod", vod_stream["direct_source"])
            self.__add_menu_item(label=vod_stream["name"], url=url, icon=icon, fanart=self.default_fanart, isfolder=False)
        xbmcplugin.endOfDirectory(__handle__)

    # ALL STREAMS

    def show_all_live_streams(self, data):
        for live_stream in data:
            url = self.make_kodi_play_url(live_stream, 'live')
            self.__add_menu_item(label=live_stream["name"], url=url, icon=self.default_icon, fanart=self.default_fanart,
                                 isfolder=False)
        xbmcplugin.endOfDirectory(__handle__)

    def show_all_vod_streams(self, data):
        for vod_stream in data:
            url = self.make_kodi_play_url(vod_stream, 'movie')
            self.__add_menu_item(label=vod_stream["name"], url=url, icon=self.default_icon, fanart=self.default_fanart,
                                 isfolder=False)
        xbmcplugin.endOfDirectory(__handle__)

    # ACCOUNT INFORMATION

    def show_account_information(self, data, args):
        url = ''
        if 'username' in args:
            self.__add_menu_item("Username: " + data['username'], url, self.default_icon, self.default_fanart, False)
        if 'password' in args:
            self.__add_menu_item("Password: " + data['password'], url, self.default_icon, self.default_fanart, False)
        if 'created_at' in args:
            member_since = datetime.datetime.fromtimestamp(int(data['created_at'])).strftime('%A %d %B %Y')
            self.__add_menu_item("Member Since: " + member_since, url, self.default_icon, self.default_fanart, False)
        if 'status' in args:
            self.__add_menu_item("Status: " + data['status'], url, self.default_icon, self.default_fanart, False)
        if 'trial' in args:
            trial = "Yes" if int(data['is_trial']) != 0 else "No"
            self.__add_menu_item("Trial Account: " + trial, url, self.default_icon, self.default_fanart,
                                 False)
        if 'exp_date' in args:
            if data['exp_date'] is None:
                exp_date = 'No Expiry'
            else:
                exp_date = datetime.datetime.fromtimestamp(int(data['exp_date'])).strftime('%A %d %B %Y %H:%M:%S')
            self.__add_menu_item("Expiry Date: " + exp_date, url, self.default_icon, self.default_fanart, False)
        if 'active_cons' in args:
            self.__add_menu_item("Active Connections: " + data['active_cons'], url, self.default_icon,
                                 self.default_fanart, False)
        if 'max_connections' in args:
            self.__add_menu_item("Max Connections: " + data['max_connections'], url, self.default_icon,
                                 self.default_fanart, False)
        if 'allowed_output_formats' in args:
            string_aof = ""
            for item in data["allowed_output_formats"]:
                if "m3u8" in item:
                    item = "HLS"
                string_aof += " " + item
            self.__add_menu_item("Allowed Output Formats:" + string_aof, url, self.default_icon, self.default_fanart, False)
        if 'auth' in args:
            self.__add_menu_item("Auth: " + str(data['auth']), url, self.default_icon, self.default_fanart, False)
        if 'message' in args and data['message'] is not None and data['message'] != '':
            self.__add_menu_item("Message: " + data['message'], url, self.default_icon, self.default_fanart, False)
        xbmcplugin.endOfDirectory(__handle__)

    # PLAY CODE

    def play(self, server_data, **kwargs):
        xtream_type = kwargs['xtream_type'] if kwargs is not None and 'xtream_type' in kwargs else self.params['xtream_type']
        xtream_name = kwargs['xtream_name'] if kwargs is not None and 'xtream_name' in kwargs else self.params['xtream_name']
        xtream_id = kwargs['xtream_id'] if kwargs is not None and 'xtream_id' in kwargs else self.params['xtream_id']

        li = xbmcgui.ListItem(label=xtream_name, iconImage=self.default_icon, thumbnailImage=self.default_icon)

        if 'direct_source' not in kwargs:
            server_info = server_data['server_info']
            user = server_data['user_info']['username']
            passw = server_data['user_info']['password']
            "Password: " + str(passw)
            url = "http://"
            stream_type = '.m3u8' if self.mpegts is False else '.ts'
            url += server_info['url'] + ':' + server_info[
                'port'] + "/" + xtream_type + "/" + user + "/" + passw + "/" + xtream_id + stream_type
            xbmc.Player().play(url, li)
        else:
            xbmc.Player().play(kwargs['direct_source'], li)

    # RESOLVER RESULTS

    def show_resolver_results(self, **kwargs):
        self.__add_menu_item("Channel Requested - " + kwargs['channel_number'], '', self.default_icon, self.default_fanart, False)
        self.__add_menu_item("Potential Matches Found", '', self.default_icon, self.default_fanart, False)
        self.__add_menu_item("-----------------------", '', self.default_icon, self.default_fanart, False)
        for possible in kwargs['possible_list']:
            possible['name'] = possible['name'] if kwargs['event_name'] is None else kwargs['event_name']
            url = self.make_kodi_play_url(possible, 'live')
            self.__add_menu_item(possible['name'], url, self.default_icon, self.default_fanart, False)
        xbmcplugin.endOfDirectory(__handle__)
