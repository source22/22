# -*- coding: utf-8 -*-
# Version Master #
# version:0.1.2 #

import json
import urllib2
import re
import base64
import urllib
import xmltodict

import view_module.view_module as vm


class Xtream:
    def __init__(self, server, user, password, live_streams=True, vod=False, **kwargs):
        self.__server = server
        self.__user = user
        self.legacy = kwargs['legacy'] if 'legacy' in kwargs else False
        self.mpegts = kwargs['mpegts'] if 'mpegts' in kwargs else False
        self.__password = password
        self.__auth_data = self.__get_json()
        self.live_streams_enabled = live_streams
        self.vod_enabled = vod
        self.stream_preference = kwargs['stream_preference'] if 'stream_preference' in kwargs else None
        self.__custom_live_streams_menu_name = kwargs[
            'custom_live_streams_menu_name'] if 'custom_live_streams_menu_name' in kwargs else None
        self.__custom_vod_menu_name = kwargs['custom_vod_menu_name'] if 'custom_vod_menu_name' in kwargs else None
        self.addon_pretty_name = kwargs[
            'addon_pretty_name'] if 'addon_pretty_name' in kwargs else "Xtream API V2 Compatible App"
        self.view = vm.ViewModule(self.stream_preference,
                                  kwargs['default_fanart'] if 'default_fanart' in kwargs else None,
                                  kwargs['default_icon'] if 'default_icon' in kwargs else None, self.mpegts)


    def get_live_stream_categories(self):
        data = self.__get_json("&action=get_live_categories")
        return data

    def get_vod_stream_categories(self):
        data = self.__get_json("&action=get_vod_categories")
        return data

    def get_live_streams_all(self):
        data = self.__get_json("&action=get_live_streams")
        return data

    def get_live_streams_by_category(self, category, with_epg_data=False):
        '''
        {u'direct_source': u'',
         u'added': u'1468271467', u'num': 67, u'name': u'xxxxxxxx', u'epg_channel_id': u'xxxxxxx',
          u'tv_archive': 0, u'stream_type': u'live', u'stream_id': 1605,
           u'custom_sid': u'', u'stream_icon': u'https://xxxxxxx',
            u'category_id': u'4', u'tv_archive_duration': 0}
        '''
        data = self.__get_json("&action=get_live_streams&category_id=", category)
        if with_epg_data is True:
            for stream in data:
                try:
                    stream['epg_data'] = self.get_short_epg_info_limit(stream['stream_id'], 1)
                except:
                    pass
        return data

    def get_vod_streams_all(self):
        data = self.__get_json("&action=get_vod_streams")
        return data

    def get_vod_streams_by_category(self, category):
        '''
        {u'direct_source': u'http://158.69.127.25/MOVIES/ENGLISH/a.storks.journey.2017.1080p.hdrip.x264.ac3-evo.mp4/index.m3u8',
         u'added': u'1497187651', u'num': 36, u'name': u'A Storks Journey',
          u'stream_type': u'movie', u'series_no': None, u'stream_id': 4344,
           u'custom_sid': u'',
            u'stream_icon': u'http://51.255.88.38:8000/images/3823116.jpg', u'container_extension': u'mp4', u'category_id': u'39'}
        '''
        data = self.__get_json("&action=get_vod_streams&category_id=", category)
        return data

    def get_vod_info(self, vod_id):
        data = self.__get_json("&action=get_vod_info&vod_id=", vod_id)
        return data

    def get_short_epg_info(self, stream_id):
        data = self.__get_json("&action=get_short_epg&stream_id=", stream_id)
        return data

    '''
    For LIVE Streams (same as stalker portal, prints the next X EPG that will play soon)
        (You can specify a limit too, without limit the default is 4 epg listings)
    '''

    def get_short_epg_info_limit(self, stream_id, limit):
        data = self.__get_json("&action=get_short_epg&stream_id=%s&limit=%s" % (stream_id, limit))
        return data

    def get_full_epg_info(self, stream_id):
        data = self.__get_json("&action=get_simple_data_table&stream_id=", stream_id)
        return data

    def __get_json(self, request_string=None, param=None):
        url = self.__server + "/player_api.php?username=" + self.__user + "&password=" + self.__password
        if request_string is not None:
            url += str(request_string)
        if param is not None:
            url += str(param)

        data = urllib2.urlopen(url, timeout=20).read()
        print '__get_json return = ' + str(data)
        data = json.loads(data)

        return data

    def login(self):
        print 'login called'
        #  We should have api details for user now
        # Successful login tested against Status
        # Status can be "Active, Banned, Disabled, Expired"
        if 'user_info' in self.__auth_data:
            print 'user info is in returned data'
            if 'status' in self.__auth_data['user_info']:
                print 'status is in returned data'
                status = self.__auth_data['user_info']['status']
                print 'returned status is = ' + str(status)
                if status == "Active":
                    print 'successful auth, user is active'
                    return True
                elif status == "Banned":
                    # Give Message
                    self.view.modal(self.addon_pretty_name, "Your account has been banned!")
                    return False
                elif status == "Disabled":
                    # Give Message
                    self.view.modal(self.addon_pretty_name, "Your account has been disabled!")
                    return False
                elif status == "Expired":
                    # Give Message
                    self.view.modal(self.addon_pretty_name, "Sorry, your account has expired!")
                    return False
            else:
                return False
        else:
            return False

    def __initial_menu(self):
        live_menu_name = None
        vod_menu_name = None
        live_categories = None
        vod_categories = None

        if self.live_streams_enabled is True:
            live_menu_name = self.__custom_live_streams_menu_name if self.__custom_live_streams_menu_name is not None else "Live Streams"
            live_categories = self.get_live_stream_categories()

        if self.vod_enabled is True:
            vod_menu_name = self.__custom_vod_menu_name if self.__custom_vod_menu_name is not None else "Video on Demand"
            vod_categories = self.get_vod_stream_categories()

        self.view.show_main_menu(live_menu_name, vod_menu_name, live_categories, vod_categories)

    def resolve_channel_by_number(self, channel_number, event_name=None):
        target_str = str(channel_number)
        target_len = str(len(target_str))
        number_pattern = r"([0-9]{" + target_len + ",})"

        streams = self.get_live_streams_all()
        possible_list = []
        for stream in streams:
            matches = re.search(number_pattern, stream['name'])
            if matches is not None:
                number = int(matches.group(1))
                if number == int(channel_number):
                    possible_list.append(stream)

        if len(possible_list) > 0:
            self.view.show_resolver_results(channel_number=channel_number, event_name=event_name,
                                            possible_list=possible_list)
        else:
            self.view.modal("Stream Not Found",
                            "It appears no match for that channel (%s) could be found" % channel_number)

    def resolve_channel_by_number_auto(self, channel_number, event_name=None):
        target_str = str(channel_number)
        target_len = str(len(target_str))
        number_pattern = r"([0-9]{" + target_len + ",})"
        streams = self.get_live_streams_all()
        feeds = []
        for stream in streams:
            matches = re.search(number_pattern, stream['name'])
            if matches is not None:
                number = int(matches.group(1))
                if number == int(channel_number):
                    feeds.append(stream)

        if not feeds:
            self.view.modal("Stream Not Found",
                            "It appears no match for that channel (%s) could be found" % channel_number)
        if feeds:
            name = str(feeds[0]['name']) if event_name is None else event_name
            if feeds[0]['direct_source']:
                self.view.play(self.__auth_data, xtream_type="live", xtream_name=name,
                               xtream_id=str(feeds[0]['stream_id']),
                               direct_source=feeds[0]['direct_source'])
            else:
                self.view.play(self.__auth_data, xtream_type="live", xtream_name=name,
                               xtream_id=str(feeds[0]['stream_id']))

    def resolve_channel_by_number_and_string_auto(self, channel_name, channel_number, event_name=None):

        target_str = str(channel_number)
        target_len = str(len(target_str))
        number_pattern = r"([0-9]{" + target_len + ",})"
        streams = self.get_live_streams_all()
        feeds = []
        for stream in streams:
            matches = re.search(number_pattern, stream['name'])
            if matches is not None:
                number = int(matches.group(1))
                if number == int(channel_number):
                    feeds.append(stream)

        keep = []
        for feed in feeds:
            if channel_name in feed['name']:
                keep.append(feed)

        final = []
        for feed in keep:
            number_index = feed['name'].index(channel_number)
            if not feed['name'][number_index - 1].isdigit():
                if (number_index + int(target_len) + 1) <= len(feed['name']):
                    if not feed['name'][number_index + int(target_len) + 1].isdigit():
                        final.append(feed)
                else:
                    final.append(feed)

        if not final:
            self.view.modal("Stream Not Found", "It appears no match for that channel: \"%s %s\" could be found" % (
            channel_name, channel_number))
        if final:
            name = str(final[0]['name']) if event_name is None else event_name
            if final[0]['direct_source']:
                self.view.play(self.__auth_data, xtream_type="live", xtream_name=name,
                               xtream_id=str(final[0]['stream_id']),
                               direct_source=feeds[0]['direct_source'])
            else:
                self.view.play(self.__auth_data, xtream_type="live", xtream_name=name,
                               xtream_id=str(final[0]['stream_id']))

    def controller(self, params):
        '''
        The purpose of this method is to control all usage of xtream,
        This allows addon users to add one route to there addon for xtream
        and the script do the rest if that"s how they roll.

        In-addon add a check for mode == xtream, then pass to xtream.controller
        '''
        if "xtream_mode" in params:
            mode = params["xtream_mode"]
            p_cat_id = params['parent_category_id'] if 'parent_category_id' in params else "0"
            if mode == "live_stream_main_menu":
                self.view.show_live_stream_categories(self.get_live_stream_categories())
            elif mode == "vod_main_menu":
                # Need to check if the given category has streams too for display
                streams = self.get_vod_streams_all()
                self.view.show_vod_categories(self.get_vod_stream_categories(), p_cat_id, streams)
            elif mode == "show_streams_by_category":
                if self.legacy is True:
                    self.view.show_live_stream_category(
                        self.get_live_television_channels_for_category(params["xtream_category"]))
                else:
                    self.view.show_live_stream_category(self.get_live_streams_by_category(params["xtream_category"]))
            elif mode == "show_vod_by_category":
                self.view.show_vod_category(self.get_vod_streams_by_category(params["xtream_category"]))
            elif mode == "show_all_live_streams":
                self.view.show_all_live_streams(self.get_live_streams_all())
            elif mode == "show_all_vod_streams":
                self.view.show_all_vod_streams(self.get_vod_streams_all())
            elif mode == "show_account_information" and "xtream_account_args" in params:
                self.view.show_account_information(self.__get_json()['user_info'], params['xtream_account_args'])
            elif mode == "play":
                self.view.play(server_data=self.__auth_data)
        else:
            self.__initial_menu()

    # LEGACY CODE
    def decodeText(self, text):
        return base64.b64decode(text)

    def get_live_television_channels_for_category(self, cat_id):
        request = {'username': self.__user, 'password': self.__password, 'type': 'get_live_streams', 'cat_id': cat_id}
        request = urllib.urlencode(request)

        request = urllib2.urlopen(self.__server + '/enigma2.php', request, timeout=5).read()
        root = json.dumps(xmltodict.parse(request))
        root = json.loads(root)

        try:
            root = root['items']['channel']
        except KeyError:
            return False
        channels = []
        '''
        {u'stream_url': u'http://51.255.88.38:8000/live/Hercule/twatfuckbollocks/2041.ts',
         u'desc_image': u'http://www.bbc.co.uk/cumbria/content/images/2007/10/23/bbc_one_logo_170x134.jpg', 
         u'description': u'WzAwOjIwXSBCQkMgTmV3cwooIEJCQaGUgaGVhZGxpbmVzIQpgYXQgMjUgYW5kIDU1IG1pbnV0ZXMgcGFzdCBlYWNoIGhvdXIobikpCg==',
          u'category_id': u'4', u'title': u'QkJDIE9uZSBIRCBbMDA6MjAgLSAwNjowMF0gKyAyMzUuOSBtaW4gICBCQkMgTmV3cw=='}
        '''
        for channel in root:
            print channel
            channel_name = channel['title']  # self.decodeText(channel['title'])
            channel_name = channel_name.strip()
            channel_description = channel['description'] if channel['description'] is not None else ''
            channel_image = channel['desc_image']
            channel_category_id = channel['category_id']
            channel_stream_url = channel['stream_url']
            pattern = r"/(\d+)\.ts"
            matches = re.search(pattern, channel['stream_url'])
            channel_id = matches.group(1) if matches else '123'
            ext = '.m3u8' if self.mpegts is False else '.ts'
            channel_stream_url = channel_stream_url.replace('.m3u8', ext).replace('.ts', ext)
            channels.append({
                'name': self.decodeText(channel_name),
                'description': self.decodeText(channel_description),
                'stream_icon': channel_image,
                'category_id': channel_category_id,
                'direct_source': channel_stream_url,
                'stream_id': channel_id
            })
        return channels
