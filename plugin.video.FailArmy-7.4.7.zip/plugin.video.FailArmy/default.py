﻿import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools
from addon.common.addon import Addon

addonID = 'plugin.video.FailArmy'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'

fan01 = 'special://home/addons/plugin.video.FailArmy/resources/fanart.jpg'
icon01 = 'special://home/addons/plugin.video.FailArmy/resources/fail.army.nation.jpg'
icon02 = 'special://home/addons/plugin.video.FailArmy/resources/best.epic.fail.compilations.jpg'
icon03 = 'special://home/addons/plugin.video.FailArmy/resources/fail.army.nation.jpg'
icon04 = 'special://home/addons/plugin.video.FailArmy/resources/failarmy.special.jpg'
icon05 = 'special://home/addons/plugin.video.FailArmy/resources/fail.compilations.jpg'
icon06 = 'special://home/addons/plugin.video.FailArmy/resources/best.fails.of.month.jpg'
icon07 = 'special://home/addons/plugin.video.FailArmy/resources/best.pranks.jpg'
icon08 = 'special://home/addons/plugin.video.FailArmy/resources/ultimate.fails.compilations.jpg'
icon09 = 'special://home/addons/plugin.video.FailArmy/resources/best.fails.of.year.jpg'
icon10 = 'special://home/addons/plugin.video.FailArmy/resources/best.girls.fails.jpg'
icon11 = 'special://home/addons/plugin.video.FailArmy/resources/failarmy.presents.jpg'
icon12 = 'special://home/addons/plugin.video.FailArmy/resources/top.fail.breakdown.jpg'

def run():
    plugintools.log("FailArmy.run")
    params = plugintools.get_params()
    if params.get("action") is None: main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    plugintools.close_item_list()

def main_list(params):
	plugintools.log("FailArmy ===> " + repr(params))
	
	plugintools.add_item(title = "Fail Army Nation", url = base + "playlist/ PLOWSbqDrrI5R8DOFeiELy8AeF4mYfSmr6/", thumbnail = icon01, fanart = fan01, folder = True)
	plugintools.add_item(title = "Best Epic Fail Comps", url = base + "playlist/PLOWSbqDrrI5Tb6W1EP9WZEaWTP6Ij-6bg/", thumbnail = icon02, fanart = fan01, folder = True)
	plugintools.add_item(title = "FA's: Best Fails of the Week", url = base + "playlist/PLOWSbqDrrI5QU6-kEuXq2eFqWZ3po6yHh/", thumbnail = icon03, fanart = fan01, folder = True)
	plugintools.add_item(title = "FA's: Best Themed Comps", url = base + "playlist/PLOWSbqDrrI5RV1I7JKTWQnvJpjgqC_yzD/", thumbnail = icon04, fanart = fan01, folder = True)
	plugintools.add_item(title = "Fails Comps", url = base + "playlist/PLOWSbqDrrI5SdB-94JSje7hGeNWxXrmt5/", thumbnail = icon05, fanart = fan01, folder = True)
	plugintools.add_item(title = "FA's: Best Fails of the Month", url = base + "playlist/PLOWSbqDrrI5T4AY9D66nqASG6r7rD2XPC/" , thumbnail = icon06, fanart = fan01, folder = True)	
	plugintools.add_item(title = "FA's: Best Pranks", url = base + "playlist/PLOWSbqDrrI5TXzoc53GY1QSTlnPri8gtx/", thumbnail = icon07, fanart = fan01, folder = True)
	plugintools.add_item(title = "Ultimate Fails Comps", url = base + "playlist/PLOWSbqDrrI5Tdgvmzjk3GSTS0uYsKoDpR/", thumbnail = icon08, fanart = fan01, folder = True)
	plugintools.add_item(title = "FA'S: Best Fails of the Year", url = base + "playlist/PLOWSbqDrrI5RduOdcj7GECH8uVUGvbwaz/", thumbnail = icon09, fanart = fan01, folder = True)
	plugintools.add_item(title = "FA's: Best Girls Fails", url = base + "playlist/PLOWSbqDrrI5RIzPRbAVnjY1Tu0e90X1E7/", thumbnail = icon10, fanart = fan01, folder = True)
	plugintools.add_item(title = "FailArmy Presents", url = base + "playlist/PLOWSbqDrrI5RJW7iDl0AYjU0LFupouzuJ/", thumbnail = icon11, fanart = fan01, folder = True)
	plugintools.add_item(title = "FA's: Top Fails Breakdown", url = base + "playlist/PLOWSbqDrrI5Rh8rqzTyk_mYLITpPTldaA/", thumbnail = icon12, fanart = fan01, folder = True)
	
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(500)')
	
run()
