import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLkludGVyc3RlbGxhckxpdmVUdg==')

name = b.b64decode('W0NPTE9SZ29sZF1JbnRlcnN0ZWxsYXIgTGl2ZSBUdlsvQ09MT1Jd')

host = b.b64decode('aHR0cDovL2R1YmxpbmlwdHYuZGRucy5uZXQ='
)
port = b.b64decode('ODM=')