import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmV0ZXJuYWw=')

name = b.b64decode('RXRlcm5hbCBUVg==')

host = b.b64decode('aHR0cDovL2xpdmUuZXRlcm5hbHR2Lm5ldA==')

port = b.b64decode('MjU0NjE=')