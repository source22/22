import json

import xbmc


def version():
    # retrieve current installed version
    query = xbmc.executeJSONRPC(
        '{ "jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["version", "name"]}, "id": 1 }')
    query = unicode(query, 'utf-8', errors='ignore')
    query = json.loads(query)
    if 'result' in query and 'version' in query['result']:
        return query['result']['version']
