'''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<settings>
    <category label="30000">
        <setting id="timezone" type="select" label="30010" lvalues="30011|30012|30013|30014|30015|30016|30017"/>
    </category>
    <category label="Main Menu Options">
        <setting id="now_playing" type="bool" label="Now Playing" default="false" visible="true"/>
        <setting id="all_events_scheduled" type="bool" label="All Events Scheduled" default="false" visible="true"/>
        <setting id="all_todays_events" type="bool" label="All Todays Events" default="false" visible="true"/>
        <setting id="by_date" type="bool" label="Events By Date" default="false" visible="true"/>
        <setting id="by_category" type="bool" label="Events By Category" default="false" visible="true"/>
        <setting id="by_date_and_category" type="bool" label="Events By Date then Category" default="false" visible="true"/>
        <setting id="by_category_and_date" type="bool" label="Events By Category then Date" default="false" visible="true"/>
    </category>
    <category label="Event Options">
        <setting id="ignore_expired" type="bool" label="Ignore Expired Events" default="false" visible="true"/>
    </category>
    <category label="View Options">
        <setting label="Menu View" type="text" id="menu_view" default="51"/>
        <setting label="Event View" type="text" id="event_view" default="51"/>
        <setting label="Channel View" type="text" id="channel_view" default="51"/>
    </category>
</settings>

Copy and paste needed from above into settings to enable the setting of the event options

***********************************
This File Is For Gathering Settings
***********************************
'''


def main_menu_options(__addon__):

    main_menu_options_list = []
    if 'true' in __addon__.getSetting('now_playing'):
        main_menu_options_list.append('now_playing')
    if 'true' in __addon__.getSetting('all_events_scheduled'):
        main_menu_options_list.append('all_events_scheduled')
    if 'true' in __addon__.getSetting('all_todays_events'):
        main_menu_options_list.append('all_todays_events')
    if 'true' in __addon__.getSetting('by_date'):
        main_menu_options_list.append('by_date')
    if 'true' in __addon__.getSetting('by_category'):
        main_menu_options_list.append('by_category')
    if 'true' in __addon__.getSetting('by_date_and_category'):
        main_menu_options_list.append('by_date_and_category')
    if 'true' in __addon__.getSetting('by_category_and_date'):
        main_menu_options_list.append('by_category_and_date')

    return main_menu_options_list


def timezone_(__addon__):

    return __addon__.getSetting('timezone')


def ignore_expired(__addon__):
    if "true" in __addon__.getSetting('ignore_expired'):
        return True
    else:
        return False


def filter_future(__addon__):
    if "true" in __addon__.getSetting('filter_future_date'):
        return True
    else:
        return False


def match_feeds_auto(__addon__):
    if "true" in __addon__.getSetting('auto_resolve'):
        return True
    else:
        return False


def view_modes(__addon__):
    view_modes_list = [
        __addon__.getSetting('menu_view'),
        __addon__.getSetting('event_view'),
        __addon__.getSetting('channel_view')
    ]
    return view_modes_list
