import sys
import urllib

import xbmc
import xbmcgui
import xbmcplugin

__handle__ = int(sys.argv[1])


class View(object):
    def __init__(self, icon, fanart, view_modes, main_menu_options):
        self.__icon__ = icon
        self.__fanart__ = fanart
        self.main_menu_options = main_menu_options
        self.view_modes = view_modes

    @staticmethod
    def __build_url(query):
        return sys.argv[0] + '?' + "mode=schedule&" + urllib.urlencode(query)

    @staticmethod
    def __add_menu_item(label, url, icon, fanart, isfolder=True):
        li = xbmcgui.ListItem(label=label, iconImage=icon, thumbnailImage=icon)
        li.setProperty("fanart_image", fanart)
        xbmcplugin.addDirectoryItem(__handle__, url, li, isfolder)

    def show_dates(self, dates):
        for date in dates:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_by_date", "sc_date": date[0:10]})
            self.__add_menu_item(date[0:10], url, self.__icon__, self.__fanart__)
        xbmcplugin.endOfDirectory(__handle__)

    def show_dc_pick_dates(self, dates):
        for date in dates:
            url = self.__build_url(
                {"mode": "schedule", "sc_mode": "show_dates_and_categorys_pick_category", "sc_dc_date": date[0:10]})
            self.__add_menu_item(date[0:10], url, self.__icon__, self.__fanart__)
        xbmcplugin.endOfDirectory(__handle__)

    def show_cd_pick_dates(self, dates, sc_cd_cat):
        for date in dates:
            url = self.__build_url(
                {"mode": "schedule", "sc_mode": "show_category_and_date_pick", "sc_cd_cat": sc_cd_cat,
                 "sc_cd_date": date[0:10]})
            self.__add_menu_item(date[0:10], url, self.__icon__, self.__fanart__)
        xbmcplugin.endOfDirectory(__handle__)

    def show_categories(self, category_list):
        for cat in category_list:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_by_category", "sc_cat": cat})
            self.__add_menu_item(cat, url, self.__icon__, self.__fanart__)
        xbmcplugin.endOfDirectory(__handle__)

    def show_dc_pick_category(self, category_list, sc_dc_date):
        for cat in category_list:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_date_and_category_pick", "sc_dc_cat": cat,
                                    "sc_dc_date": sc_dc_date})
            self.__add_menu_item(cat, url, self.__icon__, self.__fanart__)
        xbmcplugin.endOfDirectory(__handle__)

    def show_cd_pick_category(self, category_list):
        for cat in category_list:
            url = self.__build_url(
                {"mode": "schedule", "sc_mode": "show_categorys_and_dates_pick_date", "sc_cd_cat": cat})
            self.__add_menu_item(cat, url, self.__icon__, self.__fanart__)
        xbmcplugin.endOfDirectory(__handle__)

    def show_all_events(self, events, today):
        if len(events) == 0:
            xbmcgui.Dialog().ok("No Events", "Sorry your request produces no events.")
            return
        for event in events:
            data = event.split("~@~")
            url = self.__build_url(
                {"mode": "schedule", "sc_mode": "show_event_options", "sc_event": data[1], "sc_date": data[0]})
            if today[0:10] in data[0]:
                self.__add_menu_item(data[0][11:16] + " - " + data[2][11:16] + " - " + data[1], url, self.__icon__, self.__fanart__)
            else:
                self.__add_menu_item(data[0][0:16] + " - " + data[2][11:16] + " - " + data[1], url, self.__icon__, self.__fanart__)
        xbmc.executebuiltin('Container.SetViewMode(%s)' % self.view_modes[1])
        xbmcplugin.endOfDirectory(__handle__)

    def show_event_options(self, options_list, events_object):
        for option in options_list:
            icon_url = events_object.get_channel_image(option['channel'])
            icon = icon_url if '.png' in icon_url or '.jpg' in icon_url else self.__icon__
            url = self.__build_url({"mode": "schedule", "sc_mode": "resolve_channel", "sc_event": option['name'],
                                    "sc_channel": option['channel']})
            self.__add_menu_item("Channel " + option['channel'], url,
                                 icon, self.__fanart__)
        xbmc.executebuiltin('Container.SetViewMode(%s)' % self.view_modes[2])
        xbmcplugin.endOfDirectory(__handle__)

    def show_menu(self):
        if len(
                self.main_menu_options) == 0 or self.main_menu_options is None or 'now_playing' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_now_playing"})
            self.__add_menu_item("Now Playing", url, self.__icon__, self.__fanart__)

        if len(
                self.main_menu_options) == 0 or self.main_menu_options is None or 'all_events_scheduled' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_all_events"})
            self.__add_menu_item("All Events Scheduled", url, self.__icon__, self.__fanart__)

        if len(
                self.main_menu_options) == 0 or self.main_menu_options is None or 'all_todays_events' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_all_todays_events"})
            self.__add_menu_item("All Todays Events", url, self.__icon__, self.__fanart__)

        if len(self.main_menu_options) == 0 or self.main_menu_options is None or 'by_date' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_dates"})
            self.__add_menu_item("By Date", url, self.__icon__, self.__fanart__)

        if len(
                self.main_menu_options) == 0 or self.main_menu_options is None or 'by_category' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_categorys"})
            self.__add_menu_item("By Category", url, self.__icon__, self.__fanart__)

        if len(
                self.main_menu_options) == 0 or self.main_menu_options is None or 'by_date_and_category' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_dates_and_categorys_pick_date"})
            self.__add_menu_item("By Date and Category", url, self.__icon__, self.__fanart__)

        if len(
                self.main_menu_options) == 0 or self.main_menu_options is None or 'by_category_and_date' in self.main_menu_options:
            url = self.__build_url({"mode": "schedule", "sc_mode": "show_categorys_and_dates_pick_category"})
            self.__add_menu_item("By Category and Date", url, self.__icon__, self.__fanart__)
        xbmc.executebuiltin('Container.SetViewMode(%s)' % self.view_modes[0])
        xbmcplugin.endOfDirectory(__handle__)

    def display_error(self, heading, message):
        xbmcgui.Dialog().ok(heading, message)
